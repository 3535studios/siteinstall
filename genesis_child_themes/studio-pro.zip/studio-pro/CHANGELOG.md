# Studio Pro Theme Changelog

## [2.0.1] - 2017-06-26
* Clean up doc comments and update readme
* Organize helpers.php and functions.php
* Move languages pot file to sub directory
* Remove unused images

## [2.0.0] - 2017-06-20
* Remove customizer toolkit dependency
* Remove Easy Widget Columns and Widgetized Page Template dependency
* Remove clean-up functionality, use Roots Soil instead
* Clean up directory structure
* General updates for Gulp, Sass, i18n

## [1.0.0] - 2017-04-02
* Initial commit
